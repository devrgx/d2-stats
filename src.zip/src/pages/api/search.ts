import type { APIRoute } from "astro";

export const POST: APIRoute = async ({ request }) => {
  const { query } = await request.json();

  if (!query || query.length < 2) {
    return new Response(JSON.stringify([]), { status: 200 });
  }

  // name#code trennen
  let displayName = query;
  let displayNameCode = null;
  if (query.includes("#")) {
    const parts = query.split("#");
    displayName = parts[0];
    displayNameCode = parseInt(parts[1]);
  }

  const res = await fetch(
    "https://www.bungie.net/Platform/Destiny2/SearchDestinyPlayerByBungieName/All/",
    {
      method: "POST",
      headers: {
        "X-API-Key": import.meta.env.PUBLIC_BUNGIE_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        displayName,
        displayNameCode,
      }),
    }
  );

  const data = await res.json();
  const results = (data.Response || []).map((p: any) => ({
    displayName: `${p.bungieGlobalDisplayName}#${p.bungieGlobalDisplayNameCode}`,
    membershipType: p.membershipType,
    membershipId: p.membershipId,
  }));

  return new Response(JSON.stringify(results), {
    headers: { "Content-Type": "application/json" },
  });
};