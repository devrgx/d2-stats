export const APP_VERSION = "0.1.0";
export const APP_STATUS = "Early Preview";